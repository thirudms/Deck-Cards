var app = angular.module('myApp', []);
app.controller('CardsCtrl', function($scope) {
	// default order cards 
	//s for spades
	//d for diamond
	//c for clubs
	//h for hearts
	//j for joker
  	var allcards = [
		's a', 's ii', 's iii', 's iv', 's v', 's vi', 's vii', 's viii', 's ix', 's x', 's j', 's q', 's k',
		'd a', 'd ii', 'd iii', 'd iv', 'd v', 'd vi', 'd vii', 'd viii', 'd ix', 'd x', 'd j', 'd q', 'd k',
		'c a', 'c ii', 'c iii', 'c iv', 'c v', 'c vi', 'c vii', 'c viii', 'c ix', 'c x', 'c j', 'c q', 'c k',
		'h a', 'h ii', 'h iii', 'h iv', 'h v', 'h vi', 'h vii', 'h viii', 'h ix', 'h x', 'h j', 'h q', 'h k',
		'joker joker1', 'joker joker2'
	];

	// total draw cards, when user click on draw button, it will add here
	$scope.openedcards = [];

	// default it will same as 'allcards', from here draw card will pick
	$scope.shufflecards = angular.copy(allcards);

	// it will re arriage 'shufflecards' all cards as per 'shuffle' randam funtion
	$scope.shuffleAll = function() {
	$scope.reset();
	shuffle($scope.shufflecards);
	}

	// it will set to default order 'allcards'
	$scope.reset = function() {
	  $scope.shufflecards = angular.copy(allcards);
	  $scope.openedcards = [];
	  $scope.recentOpenCard = '';
	}

	// it will select first card from 'shufflecards' and add into 'openedcards'
	$scope.pickCard = function() {
	  /*$scope.openedcards.unshift($scope.shufflecards.shift());
	  $scope.recentOpenCard = $scope.openedcards[0];*/

	  $scope.openedcards.push($scope.shufflecards.shift());
	  $scope.recentOpenCard = $scope.openedcards[$scope.openedcards.length-1];
	}

	// util funtion to rearringe array order
	function shuffle(a) {
	    var j, x, i;
	    for (i = a.length; i; i--) {
	        j = Math.floor(Math.random() * i);
	        x = a[i - 1];
	        a[i - 1] = a[j];
	        a[j] = x;
	    }
	}    
});